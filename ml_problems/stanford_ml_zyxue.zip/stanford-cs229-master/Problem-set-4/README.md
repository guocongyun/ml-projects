# 1. Neural Networks: MNIST image classification

```
wget http://cs229.stanford.edu/ps/ps4/q1/nn_starter.py
wget http://cs229.stanford.edu/ps/ps4/q1/mnist.zip
```

# 4. Independent components analysis

```
wget http://cs229.stanford.edu/ps/ps4/q4/bellsej.py
wget http://cs229.stanford.edu/ps/ps4/q4/mix.dat
````
