```
http://cs229.stanford.edu/ps/ps2/spam_data.tgz
```
