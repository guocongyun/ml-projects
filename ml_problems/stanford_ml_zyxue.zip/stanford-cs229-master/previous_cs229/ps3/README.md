Data at 

```
wget https://see.stanford.edu/materials/aimlcs229/PS3-data.zip
```
