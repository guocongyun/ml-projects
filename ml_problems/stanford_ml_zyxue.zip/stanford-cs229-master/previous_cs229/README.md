Stuffs here are still in draft.


For written solutions, the solution pdf from Stanford could be very useful in
addition to my own answers in Jupyter notebook.

https://see.stanford.edu/Course/CS229
